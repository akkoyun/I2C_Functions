# I2C_Functions
Generic I2C Functions.
